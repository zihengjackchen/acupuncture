WANG'S HARMONY ACUPUNCTURE
Traditional medicine. Personal care.

Current identity: option G. Original treatment scene with refined contours, jade/sage colors and Cormorant Garamond / DM Sans typography.

Open brand-guide.html for previews, colors, usage notes and individual downloads.
logos/: outlined horizontal and stacked logos, symbol, black/ivory variants and transparent PNG exports.
editable/: vector masters with live typography. Matching TTF files are in fonts/.
wallpaper-*: centered artwork on ivory, at 1920x1080 and 3840x2160.
wallpaper-jade-*: ivory artwork on jade at the same dimensions.
social-preview.png: 1200x630 preview.
fonts/: fonts and their licenses.

Rebuild from the repository with npm run brand.
The original identity package remains in assets/brand/archive-original-a/.
Earlier options remain in assets/brand/options/ and assets/brand/archive-v1/.
