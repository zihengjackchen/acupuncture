WANG'S HARMONY ACUPUNCTURE
Traditional medicine. Personal care.

Current identity: option G with increased space below the name. Original treatment scene, jade/sage colors, Cormorant Garamond / DM Sans typography.

Open brand-guide.html for thumbnail previews, colors, usage notes and individual downloads.
logos/: outlined horizontal and stacked logos, symbol, black/ivory variants and transparent PNG exports.
editable/: vector masters with live typography. Matching TTF files are in fonts/.

WALLPAPERS
Three color sets: ivory (jade logo), jade (ivory logo), sage (jade logo).
Landscape 16:9: 3840x2160 and 1920x1080 PNG.
Portrait 3:4: 1440x1920 PNG.
Portrait 4:5: 1080x1350 PNG.
Story / phone 9:16: 1080x1920 PNG.
Square 1:1: 1080x1080 PNG.

Filename pattern: wallpapers/{color}-{orientation}-{ratio}-{width}x{height}.png
Examples: wallpapers/ivory-landscape-16x9-3840x2160.png and wallpapers/sage-story-9x16-1080x1920.png.
Outlined vectors: wallpapers/{color}-{orientation}-{ratio}.svg
Live-type masters: editable/wallpapers/{color}-{orientation}-{ratio}.svg
Portrait and square artwork uses the stacked logo, centered with generous clear space.

The older wallpaper-*.png and wallpaper-jade-*.png filenames remain available.
social-preview.png: 1200x630 preview.
fonts/: fonts and their licenses.

Rebuild from the repository with npm run brand.
The original G spacing and media pack remain in assets/brand/options/g-original-spacing/.
The original identity package remains in assets/brand/archive-original-a/.
Earlier options remain in assets/brand/options/ and assets/brand/archive-v1/.
