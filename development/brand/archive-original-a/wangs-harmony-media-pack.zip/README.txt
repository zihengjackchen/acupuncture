WANG'S HARMONY ACUPUNCTURE
Traditional medicine. Personal care.

Current identity: original logo (option A), with original colors and lettering.

Open brand-guide.html for previews, colors, usage notes and individual downloads.
logos/: original horizontal artwork, stacked layout, symbol, black/ivory variants and PNG exports.
editable/: vector masters. The lettering remains outlined; no font is required for the logo.
wallpaper-*: centered original artwork on ivory, at 1920x1080 and 3840x2160.
wallpaper-jade-*: ivory artwork on jade at the same dimensions.
social-preview.png: 1200x630 preview.
fonts/: website fonts and their licenses.

Rebuild from the repository with npm run brand.
The prior identity package remains archived in assets/brand/archive-v1/.
